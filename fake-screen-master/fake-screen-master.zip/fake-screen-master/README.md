# [Fake Screen](https://screen.now.sh)

🤔 Prank your friends with fake screens. 😲

## Themes

- [Google Search](https://screen.now.sh/google)
- [MacOS Update](https://screen.now.sh/macOS)
- [Ubuntu 18.04 Login](https://screen.now.sh/ubuntu)
- [WannaCry](https://screen.now.sh/wannacry)
- [Windows 10 Crash](https://screen.now.sh/win10-crash)
- [Windows 10 Update](https://screen.now.sh/win10-update)
- [DVD Screensaver](https://screen.now.sh/dvd-screensaver)

![overview](https://i.imgur.com/dbKTf7y.png)

## Also Try this

Windows XP 👉 https://winxp.now.sh  
Repo 👉 https://github.com/ShizukuIchi/winXP
