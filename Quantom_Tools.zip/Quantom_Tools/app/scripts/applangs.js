﻿/*!
 This file is part of DecSoft App Builder.
 Visit our website for license information.
 Copyright ©2020 DecSoft. All rights reserved.
 Visit our website at: https://www.decsoftutils.com
 */

window.appLangs = [];

window.appLangs["en"] = {

  language: {
    name: "English"
  },

  resources: {
  },
  sidebar: {
    items: []
  }
};
// End of window.appLangs["en"] = {
