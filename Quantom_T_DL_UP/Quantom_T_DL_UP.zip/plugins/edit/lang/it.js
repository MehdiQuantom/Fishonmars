﻿/*
 * PLUGIN EDIT
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.EditTrackers			= "Modifica Torrent...";
 theUILang.EditTorrentProperties	= "Proprietà del Torrent";
 theUILang.errorAddTorrent		= "Errore di aggiunta del file torrent";
 theUILang.errorWriteTorrent		= "Errore di scrittura del file torrent";
 theUILang.errorReadTorrent		= "Errore di lettura del file torrent";
 theUILang.cantFindTorrent		= "File torrent di origine per questo download non trovato."

thePlugins.get("edit").langLoaded();
