﻿/*
 * PLUGIN EDIT
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.EditTrackers			= "Chỉnh sửa torrent...";
 theUILang.EditTorrentProperties	= "Các thuộc tính của Torrent";
 theUILang.errorAddTorrent		= "Lỗi khi thêm tập tin torrent";
 theUILang.errorWriteTorrent		= "Lỗi khi ghi tập tin torrent";
 theUILang.errorReadTorrent		= "Lỗi khi đọc tập tin torrent";
 theUILang.cantFindTorrent		= "Không tìm thấy tập tin torrent gốc."

thePlugins.get("edit").langLoaded();