﻿/*
 * PLUGIN DATADIR
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.DataDir		= "Lưu vào";
 theUILang.DataDirMove		= "Di chuyển các tập tin dữ liệu";
 theUILang.datadirDlgCaption	= "Thư mục chứa dữ liệu Torrent";
 theUILang.datadirDirNotFound	= "Gói bổ sung DataDir: Thư mục không hợp lệ";
 theUILang.datadirSetDirFail	= "Gói bổ sung DataDir: Quá trình thực hiện thất bại";

thePlugins.get("datadir").langLoaded();