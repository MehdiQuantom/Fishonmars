﻿/*
 * PLUGIN DATADIR
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.DataDir		= "Salva in";
 theUILang.DataDirMove		= "Sposta i file dati";
 theUILang.datadirDlgCaption	= "Cartella dati del torrent";
 theUILang.datadirDirNotFound	= "DataDir plugin: Cartella non valida";
 theUILang.datadirSetDirFail	= "DataDir plugin: Operazione fallita";

thePlugins.get("datadir").langLoaded();
