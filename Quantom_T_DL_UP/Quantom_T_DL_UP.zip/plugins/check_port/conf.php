<?php
// configuration parameter

$useWebsite = "yougetsignal";	// Valid choices:
				// false - disable check_port plugin
				// "yougetsignal" - use https://www.yougetsignal.com/tools/open-ports/
				// "portchecker" - use https://portchecker.co/
