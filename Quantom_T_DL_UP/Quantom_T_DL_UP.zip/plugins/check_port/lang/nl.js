﻿/*
 * PLUGIN CHECK_PORT
 *
 * Dutch language file.
 *
 * Author: 
 */

 theUILang.checkWebsiteNotFound = "Check_port plugin: Plugin will not work. Invalid configuration";
 theUILang.checkPort		= "Check Port Status";
 theUILang.portStatus		= [
 				  "Port status is unknown",
 				  "Port is closed",
 				  "Port is open"
 				  ];

thePlugins.get("check_port").langLoaded();