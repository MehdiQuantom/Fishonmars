﻿/*
 * PLUGIN CHUNKS
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.Chunks		= "Pièces";
 theUILang.cAvail		= "Disponibilité";
 theUILang.cDownloaded		= "Téléchargé";
 theUILang.cMode		= "Mode";
 theUILang.chunksCount		= "Nombre de pièces";
 theUILang.chunkSize		= "Taille d'une pièce";
 theUILang.cLegend		= "Légende";
 theUILang.cLegendVal		= [ "4 pièces par cellule", "1 pièce par cellule" ];

thePlugins.get("chunks").langLoaded();
