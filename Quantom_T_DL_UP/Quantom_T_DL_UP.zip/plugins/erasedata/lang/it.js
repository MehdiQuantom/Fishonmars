﻿/*
 * PLUGIN ERASEDATA
 *
 * Italian language file.
 *
 * Author: Gianni
 */

 theUILang.Rem_torrents_content_prompt		= "Vuoi veramente rimuovere i torrent selezionati? ATTENZIONE: Questo cancellerà i contenuti dei torrent.";
 theUILang.Delete_data_with_path		= "Cancella cartella";
 theUILang.Rem_torrents_with_path_prompt	= "Vuoi veramente rimuovere i torrent selezionati? ATTENZIONE: Questo cancellerà tutti i file nella cartella di questi torrent.";

thePlugins.get("erasedata").langLoaded();
